package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import modelo.Principal;
/**
 * Test class.
 * @author Juan Agust�n Lizarazo
 *
 */
class PruebaClaseEspecial {

	/**
	 * Attribute for the principal class of the model.
	 */
	private Principal principal;
	
	/**
	 * The first escenario consist in the phase of the organized the costumers after they choose their books.
	 */
	public void escenario1() {
		
		principal = new Principal();
		principal.loadFile("Entrada.txt");
		principal.OrganizedClients();
		
	}
	
	/**
	 * This escenario consist in the process of buying and packaging the products.
	 */
	public void escenario2() {
		principal = new Principal();
		principal.loadFile("Entrada2.txt");
		principal.OrganizedClients();
		principal.cashierSection();
		
	}
	/**
	 * The test compares the cedula of the client with less books, that represent the person that spend the less time choosing their book in the first phase.
	 */
	@Test
	void testClienteMenosTiempoSeleccion() {
		
		escenario1();
		assertEquals(2100, principal.getClOrg().peek().getCedula());
	}
	
	/**
	 * This test consist in the next step, where the values pass to the cashier so the queue is empty.
	 */
	@Test
	
	void testSeVaciaLaColaDePrioridad() {
		escenario2();
		assertEquals(true, principal.getClOrg().isEmpty());
	}
	
	/**
	 * In this phase, we know the client with the less time in the final of the process, so we compare his cedula with the value store in the principal class.
	 */
	@Test
	
	void testColaDePrioridadFinal() {
		
		escenario2();
		assertEquals(2029, principal.getPrimeraCedula());
	}

}
