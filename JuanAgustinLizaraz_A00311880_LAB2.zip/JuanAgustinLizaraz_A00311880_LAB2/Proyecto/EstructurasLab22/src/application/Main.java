package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import modelo.Principal;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

/**
 * This class show and changes the screen of the program.
 * @author Juan Agust�n Lizarazo
 *
 */
public class Main extends Application {
	
	/**
	 * Principal class of the model
	 */
	private Principal principal;
	/**
	 * The stage of the current screen
	 */
	private Stage primaryStage;
	/**
	 * The border pane of the current screen
	 */
	private BorderPane root;
	/**
	 * Attribute String that contains the final message, with the values of the process.
	 */
	private static String valoresFinales;
	@Override
	public void start(Stage primaryStage) {
		try {
			
			
			
			
			
			this.primaryStage = primaryStage;
			
			this.primaryStage.initStyle(StageStyle.DECORATED);
			this.primaryStage.setTitle("Bienvenido");
			this.root = (BorderPane)FXMLLoader.load(getClass().getResource("Special.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Method that returns the principal object
	 * @return principal
	 */
	public Principal getPrincipal() {
		return principal;
	}


	/**
	 * Method that returns the current stage
	 * @return primaryStage
	 */
	public Stage getPrimaryStage() {
		return primaryStage;
	}


	/**
	 * Method that returns the current borderpane
	 * @return root
	 */
	public BorderPane getRoot() {
		return root;
	}


	/**
	 * Method that returns the message of the process
	 * @return
	 */
	public String getValoresFinales() {
		return valoresFinales;
	}


	/**
	 * Method that modifies the principal object.
	 * @param principal
	 */
	public void setPrincipal(Principal principal) {
		this.principal = principal;
	}


	/**
	 * Method that modifies the current stage.
	 * @param primaryStage
	 */
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}


	/**
	 * Method that modifies the current border pane.
	 * @param root
	 */
	public void setRoot(BorderPane root) {
		this.root = root;
	}


	/**
	 * Method that modifies the final message
	 * @param valoresFinales
	 */
	public void setValoresFinales(String valoresFinales) {
		this.valoresFinales = valoresFinales;
	}



	public static void main(String[] args) {
		launch(args);
	}
}
