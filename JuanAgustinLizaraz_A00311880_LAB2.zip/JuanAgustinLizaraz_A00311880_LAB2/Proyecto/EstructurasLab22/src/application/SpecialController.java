package application;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import modelo.Principal;
/**
 * This class show the message of the final program.
 * @author Juan Agust�n Lizarazo
 *
 */
public class SpecialController {
	/**
	 * Instancia de la clase principal del mundo
	 */
	
	private Principal principal;
	/**
	 * Attribute textfield for the rute
	 */
    @FXML
    private TextField ruteTXT;
    /**
     * Attribute for the explore button
     */
    @FXML
    private Button exploreBTN;
    
    /**
     * Attribute for the load button.
     */

    @FXML
    private Button loadBTN;
	/**
	 * Instance of the main class
	 */
	private Main main;
	/**
	 * The text area that the user visualize in the program.
	 */
    @FXML
    private TextArea txtArea;
    
    public SpecialController() {
    	
    }
  
    /**
     * Method of initialize
     */
    public void initialize() {
    	iniciar();
    	
    	
    }

    /**
     * This method defines main object, and the text of the text area.
     */
    public void iniciar() {
    	main = new Main();
    	principal = new Principal();
    	
    }
    
    /**
     * Method for the action after press explore button
     * @param event
     */
    @FXML
    void exploreArchive(ActionEvent event) {
    
 		   JFileChooser chooser = new JFileChooser();
 		    FileNameExtensionFilter filter = new FileNameExtensionFilter(
 		        "Archivos", "csv");
 		    chooser.setFileFilter(filter);
 		    int returnVal = chooser.showOpenDialog(null);
 		    if(returnVal == JFileChooser.APPROVE_OPTION) {
 		      
 		            ruteTXT.setText(chooser.getSelectedFile().getPath());
 		            loadBTN.setDisable(false);
 		    }
 			
 	
    	
    }

    /**
     * Method for the action after press load button.
     * @param event
     */
    @FXML
    void loadArchive(ActionEvent event) {
    	
    	
    	principal.loadFile(ruteTXT.getText());
    	
    	principal.OrganizedClients();
		principal.cashierSection();
		txtArea.setText(principal.getTexto());
    }
}
