package modelo;
/**
 * Class for the books.
 * @author Juan Agust�n Lizarazo
 *
 */
public class Book {
	
	/**
	 * Attribute that defines the code of the book
	 */
	private int code;
	/**
	 * Method that defines the price of the book.
	 */
	private int price;
	/**
	 * Method that defines the number of the book.
	 */
	private int number;

	/**
	 * Constructor method of the book, the price its generate in random.
	 */
	public Book() {
		price = (int) (Math.random() * 10000);
	}

	/**
	 * Method that returns the code
	 * @return code
	 */
	public int getCode() {
		return code;
	}

	/**
	 * Method that returns the price.
	 * @return price
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * Method that returns the number of the book.
	 * @return number
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * Method that modifies the code of the book.
	 * @param code
	 */
	public void setCode(int code) {
		this.code = code;
	}

	/**
	 * Method that modifies the price of the book.
	 * @param price
	 */
	public void setPrice(int price) {
		this.price = price;
	}

	/**
	 * Method that modifies the number of the book.
	 * @param number
	 */
	public void setNumber(int number) {
		this.number = number;
	}
	
	

}
