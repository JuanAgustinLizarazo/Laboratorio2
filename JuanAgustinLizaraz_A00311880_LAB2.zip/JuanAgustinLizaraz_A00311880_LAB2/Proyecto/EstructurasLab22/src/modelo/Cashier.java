package modelo;

import java.util.PriorityQueue;
import java.util.Stack;

/**
 * Class for the cashier of the library
 * @author Juan Agust�n Lizarazo
 *
 */
public class Cashier {
	
	/**
	 * Attribute that defines if the cashier is free
	 */
	private boolean free;
	

	/**
	 * Stack for the payed books.
	 */
	private Stack<Book> payedBooks;
	
	/**
	 * Stack for the packed books.
	 */
	private Stack<Book> packedBooks;
	
	/**
	 * Attribute integer for the packed time.
	 */
	private int timePacked;
	
	/**
	 * Attribute integer for the payed time.
	 */
	private int timePayed;

	/**
	 * Constructor method.
	 */
	public Cashier() {
		free = true;
		
		timePacked = (int) (Math.random() * 10) + 10;
		
		timePayed = (int) (Math.random() * 10) + 10;
	}



	/**
	 * Method that returns the Stack of payed books.
	 * @return payedBooks.
	 */
	public Stack<Book> getPayedBooks() {
		return payedBooks;
	}

	/**
	 * Method that returns the Stack of Packed books.
	 * @return packedBooks
	 */
	public Stack<Book> getPackedBooks() {
		return packedBooks;
	}
	
	/**
	 * Methos that returns true if the cashier is free
	 * @return free
	 */
	public boolean isFree() {
		return free;
	}

	/**
	 * Method that modifies the boolean free.
	 * @param free
	 */
	public void setFree(boolean free) {
		this.free = free;
	}


	/**
	 * Method that modifies the Stack of payed books.
	 * @param payedBooks
	 */
	public void setPayedBooks(Stack<Book> payedBooks) {
		this.payedBooks = payedBooks;
	}

	/**
	 * Method that modifies the packed books.
	 * @param packedBooks
	 */
	public void setPackedBooks(Stack<Book> packedBooks) {
		this.packedBooks = packedBooks;
	}
	
	/**
	 * Methos that defines the proccess of payed and packaging, calculate the time, and modifies the book Stack order of the client.
	 * @param a client
	 * @return client
	 */
	public Clients attendance(Clients a) {
		free = false;
		payedBooks = new Stack<Book>();
		packedBooks = new Stack<Book>();
		
		while(a.getBooks() != null&& !a.getBooks().isEmpty()) {
			Book auxBook = a.getBooks().pop();
			a.setPayedMoney(a.getPayedMoney() + auxBook.getPrice());
			payedBooks.add(auxBook);
			a.setTime(a.getTime() + timePayed);
			
		}
		
		while(payedBooks != null && !payedBooks.isEmpty()) {
			
			Book auxBook = payedBooks.pop();
			
			packedBooks.add(auxBook);
			a.setTime(a.getTime() + timePacked);
			
		}
		a.setBooks(packedBooks);
		free = true;
		return a;
		
		
		
	}

	
	
}
