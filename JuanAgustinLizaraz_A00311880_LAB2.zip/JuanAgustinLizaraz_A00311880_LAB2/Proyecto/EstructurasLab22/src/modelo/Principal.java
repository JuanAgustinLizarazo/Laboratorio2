package modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;
import java.util.StringTokenizer;

import javax.swing.JFileChooser;
/**
 * Principal class of the model.
 * @author Juan Agust�n Lizarazo
 *
 */
public class Principal {
	/**
	 * Array of the clients.
	 */
	private Clients clientList[];
	/**
	 * Attribute that defines the number of books.
	 */
	
	 int numbBooks;
	 
	 /**
	  * Attribute that defines an auxiliar integer 
	  */
	 int auxClients;
	 
	 /**
	  * Attribute that defines an auxiliar stack of books.
	  */
	 Stack<Book> auxBooks;
	 
	 /**
	  * Attribute that defines a queue of clients.
	  */
	 Queue<Clients> clOrg;
	 
	 /**
	  * Attribute that defines a queue of attend clients.
	  */
	 private Queue<Clients> attendedClients;
	 
	 /**
	  * Attribute that defines a queue of clients that were attended.
	  */
	 private Queue<Clients> finishedClientsAttention;
	 
	 /**
	  * Attribute that defines the number of cashiers.
	  */
	 private int numberCashiers;
	 
	 /**
	  * Attribute that defines the number of clients.
	  */
	 private int numberClients;
	 /**
	  * Attribute that defines the number of shelving
	  */
	 private int numberShelvings;
	 
	 /**
	  * Array for the cashiers.
	  */
	 private Cashier cashiers[];
	 /**
	  * Array for the shelvings.
	  */
	 private Shelving shelvings[];
	 
	 /**
	  * Attribute file.
	  */
	 File archivo = null;
	 
	 /**
	  * Attribute file reader.
	  */
     FileReader fr = null;
     
     /**
      * Attribute buffered reader
      */
     BufferedReader br = null;
     
     /**
      * Attribute that defines the final text.
      */
     private String texto;
     
     /**
      * Attribute that defines the number of the first cedula.
      */
     private int primeraCedula;
	
     /**
      * Constructor method of the class.
      */
	public Principal() {
		
	}
	
	/**
	 * Method that returns the array of the clients.
	 * @return clientList
	 */
	public Clients[] getClientList() {
		return clientList;
	}

/**
 * Method that returns the number of the books.
 * @return numbBooks
 */
	public int getNumbBooks() {
		return numbBooks;
	}

	/**
	 * Method that returns the auxiliar integer
	 * @return auxClients.
	 */
	public int getAuxClients() {
		return auxClients;
	}

	/**
	 * Method that returns the auxiliar Stack.
	 * @return auxBooks.
	 */
	public Stack<Book> getAuxBooks() {
		return auxBooks;
	}

	/**
	 * Method that returns the Queue of the clients.
	 * @return clOrg
	 */
	public Queue<Clients> getClOrg() {
		return clOrg;
	}

	/**
	 * Method that returns the Queue of attended clients
	 * @return attendedClients
	 */
	public Queue<Clients> getAttendedClients() {
		return attendedClients;
	}

	/**
	 * Method that returns the Queue of the final clients attention.
	 * @return finishesClientsAttention
	 */
	public Queue<Clients> getFinishedClientsAttention() {
		return finishedClientsAttention;
	}

	/**
	 * Method that returns the number of cashiers.
	 * @return numberCashiers.
	 */
	public int getNumberCashiers() {
		return numberCashiers;
	}

	/**
	 * Method that returns the number of clients.
	 * @return numberClients.
	 */
	public int getNumberClients() {
		return numberClients;
	}
	/**
	 * Method that returns the number of shelvings.
	 * @return numberShelvings
	 */

	public int getNumberShelvings() {
		return numberShelvings;
	}

	/**
	 * Method that returns the array of cashiers.
	 * @return cashiers
	 */
	public Cashier[] getCashiers() {
		return cashiers;
	}

	/**
	 * Method that returns the array of shelvings.
	 * @return shelvings.
	 */
	public Shelving[] getShelvings() {
		return shelvings;
	}

	/**
	 * Method that returns a file.
	 * @return archivo
	 */
	public File getArchivo() {
		return archivo;
	}

	/**
	 * Method that returns the fileReader
	 * @return fr
	 */
	public FileReader getFr() {
		return fr;
	}

	/**
	 * Method that returns the buffered reader
	 * @return br
	 */
	public BufferedReader getBr() {
		return br;
	}

	/**
	 * Method that returns the final text
	 * @return texto
	 */
	public String getTexto() {
		return texto;
	}
	
	

	/**
	 * Method that returns the first cedula
	 * @return primeraCedula.
	 */
	public int getPrimeraCedula() {
		return primeraCedula;
	}

	/**
	 * Method that modifies the first cedula
	 * @param primeraCedula
	 */
	public void setPrimeraCedula(int primeraCedula) {
		this.primeraCedula = primeraCedula;
	}

	/**
	 * Method that modifies the array of clients
	 * @param clientList
	 */

	public void setClientList(Clients[] clientList) {
		this.clientList = clientList;
	}

	/**
	 * Method that modifies the number of books
	 * @param numbBooks
	 */
	public void setNumbBooks(int numbBooks) {
		this.numbBooks = numbBooks;
	}

	/**
	 * Method that modifies the auxiliar integer.
	 * @param auxClients
	 */
	public void setAuxClients(int auxClients) {
		this.auxClients = auxClients;
	}

	/**
	 * Method that modifies the auxiliar Stack.
	 * @param auxBooks
	 */
	public void setAuxBooks(Stack<Book> auxBooks) {
		this.auxBooks = auxBooks;
	}

	/**
	 * Method that modifies the queue of clients.
	 * @param clOrg
	 */

	public void setClOrg(Queue<Clients> clOrg) {
		this.clOrg = clOrg;
	}


	/**
	 * Method that modifies the queue of attended clients.
	 * @param attendedClients
	 */
	public void setAttendedClients(Queue<Clients> attendedClients) {
		this.attendedClients = attendedClients;
	}


	/**
	 * Method that modifies the queue of finished clients.
	 * @param finishedClientsAttention
	 */
	public void setFinishedClientsAttention(Queue<Clients> finishedClientsAttention) {
		this.finishedClientsAttention = finishedClientsAttention;
	}

	/**
	 * Method that modifies the number of cashiers.
	 * @param numberCashiers
	 */
	public void setNumberCashiers(int numberCashiers) {
		this.numberCashiers = numberCashiers;
	}

	/**
	 * Method that modifies the number of clients.
	 * @param numberClients
	 */

	public void setNumberClients(int numberClients) {
		this.numberClients = numberClients;
	}

	/**
	 * Method that modifies the number of shelvings.
	 * @param numberShelvings
	 */
	public void setNumberShelvings(int numberShelvings) {
		this.numberShelvings = numberShelvings;
	}


	/**
	 * Method that modifies the array of cashiers.
	 * @param cashiers
	 */
	public void setCashiers(Cashier[] cashiers) {
		this.cashiers = cashiers;
	}


	/**
	 * Method that modifies the array of shelvings.
	 * @param shelvings
	 */
	public void setShelvings(Shelving[] shelvings) {
		this.shelvings = shelvings;
	}

	/**
	 * Method that modifies the file.
	 * @param archivo
	 */

	public void setArchivo(File archivo) {
		this.archivo = archivo;
	}

	/**
	 * Method that modifies the filereader
	 * @param fr
	 */

	public void setFr(FileReader fr) {
		this.fr = fr;
	}


	/**
	 * Method that modifies the BufferedReader
	 * @param br
	 */
	public void setBr(BufferedReader br) {
		this.br = br;
	}

	/**
	 * Method that modifies the final text.
	 * @param texto
	 */

	public void setTexto(String texto) {
		this.texto = texto;
	}


	/**
	 * This method charge the initial values that are contain in the plain archive. Then it counts an initial time, for the selection of the book. 
	 * It means that the information contain in the plain document, affects at least a half of a part of the process.
	 */
	public void loadFile(String rute) {
		
		

	
		
	
	  BufferedReader filein;
	try {
		
		
		filein = new BufferedReader(new FileReader(rute));
	      String line;
	 	 int i = 1;
	 	 int j = 0;
	 	 boolean clien = false;
	      while ((line = filein.readLine()) != null) {
	         
	         StringTokenizer st = new StringTokenizer(line);
	         
	  
	         long sum = 0;
	 
	        
	         if(i == 1) {
	        	 
	        	 numberCashiers = Integer.parseInt(line);
	        	 cashiers = new Cashier[numberCashiers];
	         }
	         
	         if(i == 2) {
	         
	        	 numberShelvings = Integer.parseInt(line);
	        	 shelvings = new Shelving[Integer.parseInt(line)];
	         }

	          if(i>2&&j<numberShelvings) {
	        	 if(((int)line.charAt(0)) > 64 && ((int)line.charAt(0)) <91) {
	        		
	        		int h = 0;
		         while (st.hasMoreElements()) {
		        	 if(h==0) {
			           shelvings[j] = new Shelving(st.nextToken());
		        	 }
		        	 else {
		        		numbBooks = Integer.parseInt(st.nextToken());
		        		
		        		 shelvings[j].setNumBooks(numbBooks);
		        	 }
			           h++;
			         }
	         }
	        	 else {
	        	
					if(numbBooks>0) {
						
	        		 Book b = new Book();
	        		 int h = 0;
			         while (st.hasMoreElements()) {
			        	 if(h==0) {
				           b.setCode(Integer.parseInt(st.nextToken()));
			        	 }
			        	 if(h ==1) {
			        		 b.setPrice(Integer.parseInt(st.nextToken()));
			        	 }
			        	 if(h==2) {
			        		 b.setNumber(Integer.parseInt(st.nextToken()));
			        		 numbBooks --;
			        		 shelvings[j].put(b.getCode(), b);
			        		 
			        	 }
			        
				           h++;
				    
			         }
			         
			        if(numbBooks == 0) {
			        	j++;
			        }
	        		 }
					
					
	        		 
	        	 }
	        }
	       
	          else if(j==numberShelvings&&i>2) {
	        	 
	        	 if(!clien) {
	        	clien = true;
	        	 numberClients = Integer.parseInt(line);
	        	 clientList = new Clients[numberClients];
	        	 auxClients = 0;
	        	 }
	        	 else {
	        	if(auxClients < numberClients) {
	        		Clients b = new Clients();
	        		 int h = 0;
			         while (st.hasMoreElements()) {
			        	 if(h==0) {
				         b.setCedula(Integer.parseInt(st.nextToken()));
				         
				         auxBooks = new Stack<>();
				         
			        	 }
			        	 if(h >0) {
			        		 String token = st.nextToken();
			        		 for(int x = 0 ; x<numberShelvings; x++) {
			        	
			        			 if(shelvings[x].containsKey(Integer.parseInt(token))) {
			        				 Book f = shelvings[x].get(Integer.parseInt(token));
			        				 
			        				 int numB = f.getNumber();
			        				 if(numB>0) {
			        			 shelvings[x].get(Integer.parseInt(token)).setNumber(numB-1);
			        			 auxBooks.push( shelvings[x].get(Integer.parseInt(token)));
			        			 b.setBooks(auxBooks);
			        			 b.setTime(b.getTime() + x*5 + 5);
			        				 }
			        			 }
			        		 }
			        		 
			        		 
			        	 }
			        	
			        
				           h++;
				    
			         }
			      
			         clientList[auxClients] = b;
			    
			     	auxClients ++;
	        	}
	        	
	        	
	        
	        	 }
	         }
	         
	         
	         i++;
	      }
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (NumberFormatException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	     

	  

	 
	      
	       
	      

	   
	
}
	
	/**
	 * This method organize the clients using their time, and a priority Queue
	 */
	public void OrganizedClients() {
		 clOrg = new PriorityQueue<Clients>();
		for(int i = 0; i<clientList.length; i++) {
			clOrg.add(clientList[i]);
			
		}

	}
	
	/**
	 * This method consist in pass the priority queue to the cashiers, then they count the time, and made the process of selling and packaging.
	 * Then the value of the time and the money is passed to the client, and then it is save in a plane archive.
	 */
	public void cashierSection() {
		finishedClientsAttention = new PriorityQueue<Clients>();
		attendedClients = new LinkedList<Clients>();
		while(!clOrg.isEmpty()) {
		for(int i = 0; i<numberCashiers; i++) {
			if(cashiers[i] == null) {
				cashiers[i] = new Cashier();
			}
			if(cashiers[i].isFree()) {
			finishedClientsAttention.add(cashiers[i].attendance(clOrg.poll()));
			}
		}
		}
		writeTheFinalState();
		

	}
	
	/**
	 * The method save the final values of the process in a plane archive.
	 */
	public void writeTheFinalState() {
		try {
			
			texto = "";
			PrintWriter fileout = new PrintWriter(new FileWriter("test.out"));
			
			
			int i = 0;
			while(finishedClientsAttention != null && !finishedClientsAttention.isEmpty()) {
			
				Clients auxiliarClient = finishedClientsAttention.poll();
				if(i == 0) {
					primeraCedula = auxiliarClient.getCedula();
				}
				texto += "Cedula: " + auxiliarClient.getCedula() + " || Dinero Gastado: " + auxiliarClient.getPayedMoney() + " || Tiempo total: " + auxiliarClient.getTime()+ "\nLibros Llevados: ";
				while(auxiliarClient.getBooks() != null && !auxiliarClient.getBooks().isEmpty()) {
					Book b = auxiliarClient.getBooks().pop();
					texto += " |  "+b.getCode() + "  |  ";
				}
				texto += "\n\n";
				i++;
			}
			 
			 fileout.println(texto);
		      // Envio todos los stream al archivo
		      fileout.flush();
		      // Cierre del archivo
		      fileout.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	

}
