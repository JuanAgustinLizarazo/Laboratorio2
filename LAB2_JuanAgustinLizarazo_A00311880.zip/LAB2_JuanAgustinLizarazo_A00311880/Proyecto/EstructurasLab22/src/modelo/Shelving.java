package modelo;

import java.util.Hashtable;
/**
 * Class for shelvings, this consist in a hash table.
 * @author Juan Agust�n Lizarazo
 *
 */
public class Shelving extends Hashtable<Integer, Book>{

	/**
	 * Attribute that defines the name of the shelving.
	 */
	private String name;
	/**
	 * Attribute that defines the number of books of the shelving.
	 */
	private int numBooks;
	
	/**
	 * Constructor method of the class.
	 * @param n
	 */
	public Shelving(String n) {
		
		name = n;
		
	}

	/**
	 * Method that returns the name of the shelving.
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Method that returns the number of books of the shelving.
	 * @return numBooks.
	 */
	public int getNumBooks() {
		return numBooks;
	}

	/**
	 * Method that modifies the name of the shelving.
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Method that modifies the number of the books of the shelving.
	 * @param numBooks
	 */

	public void setNumBooks(int numBooks) {
		this.numBooks = numBooks;
	}
	
	
	
}
