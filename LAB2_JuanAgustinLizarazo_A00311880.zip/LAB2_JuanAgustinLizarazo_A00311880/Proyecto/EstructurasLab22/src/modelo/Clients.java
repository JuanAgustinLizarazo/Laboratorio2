package modelo;

import java.util.Stack;

/**
 * Class for the clients.
 * @author Juan Agust�n Lizarazo
 *
 */
public class Clients implements Comparable<Clients>{
	
	/**
	 * Attribute that defines the cedula of the client.
	 */
	private int cedula;
	/**
	 * Attribute that defines the stack of books of the client.
	 */
	private Stack<Book> books;
	/**
	 * Attribute that defines the time of the client.
	 */
	private double time;
	/**
	 * Attribute that define the money payed for the books.
	 */
	private int payedMoney;
	
	/**
	 * Constructor method of client.
	 */
	public Clients() {
		time = 0.0;
	}

	/**
	 * Methos that returns the cedula of the client.
	 * @return cedula
	 */
	public int getCedula() {
		return cedula;
	}

	/**
	 * Method that returns the stack of books of the client.
	 * @return
	 */
	public Stack<Book> getBooks() {
		return books;
	}
	
	/**
	 * Method that returns the time of the client.
	 * @return time
	 */
	public double getTime() {
		return time;
	}

	/**
	 * Method that returns the money payed of the client.
	 * @return payedMoney
	 */
	public int getPayedMoney() {
		return payedMoney;
	}

	/**
	 * Method that modifies the money payed of the client.
	 * @param payedMoney
	 */
	public void setPayedMoney(int payedMoney) {
		this.payedMoney = payedMoney;
	}

	/**
	 * Method that modifies the time of the client.
	 * @param time
	 */
	public void setTime(double time) {
		this.time = time;
	}

	/**
	 * Method that modifies the cedula of the client.
	 * @param cedula
	 */
	public void setCedula(int cedula) {
		this.cedula = cedula;
	}

	/**
	 * Method that modifies the Stack of books of the client.
	 * @param books
	 */
	public void setBooks(Stack<Book> books) {
		this.books = books;
	}

	/**
	 * Method to compare two clients in base of their time.
	 */
	@Override
	public int compareTo(Clients cl) {
        if (time > cl.getTime()) {
            return 1;
        } else if (time < cl.getTime()) {
            return -1;
        } else {
            return 0;
        }
	
	}
	
	

}
