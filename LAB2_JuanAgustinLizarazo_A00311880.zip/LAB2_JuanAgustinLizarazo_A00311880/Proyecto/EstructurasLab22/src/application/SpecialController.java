package application;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
/**
 * This class show the message of the final program.
 * @author Juan Agust�n Lizarazo
 *
 */
public class SpecialController {
	/**
	 * Instance of the main class
	 */
	private Main main;
	/**
	 * The text area that the user visualize in the program.
	 */
    @FXML
    private TextArea txtArea;
    
    public SpecialController() {
    	
    }
  
    /**
     * Method of initialize
     */
    public void initialize() {
    	iniciar();
    	
    	
    }

    /**
     * This method defines main object, and the text of the text area.
     */
    public void iniciar() {
    	main = new Main();
    	txtArea.setText(main.getValoresFinales());
    }
}
